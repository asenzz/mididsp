#!/bin/sh
mv jstrav.so $LADSPA_PATH
